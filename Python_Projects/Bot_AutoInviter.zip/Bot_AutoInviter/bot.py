from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    ChatJoinRequestHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes
)
import logging
from datetime import datetime

TOKEN = "7910705711:AAFlTlPO9lKM_d9jQk4TUgypDVF7XvDfg1s"
CHAT_ID = "-1002455676313"  # ID вашего частного чата

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("Подать заявку", callback_data='join_request')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        'Добро пожаловать! Нажмите кнопку ниже, чтобы подать заявку на вступление в чат.',
        reply_markup=reply_markup
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    if query.data == 'join_request':
        try:
            # Создаем ссылку для приглашения
            invite_link = await context.bot.create_chat_invite_link(
                chat_id=CHAT_ID,
                creates_join_request=True  # Создает запрос на вступление
            )
            
            await query.message.reply_text(
                "Для вступления в чат перейдите по ссылке. "
                "Ваша заявка будет одобрена автоматически:\n"
                f"{invite_link.invite_link}"
            )
            
            # Логируем создание ссылки
            user = query.from_user
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_message = (
                f"Создана ссылка-приглашение\n"
                f"Время: {current_time}\n"
                f"Для пользователя: {user.first_name} (ID: {user.id})"
            )
            logging.info(log_message)
            
        except Exception as e:
            logging.error(f"Ошибка при создании ссылки: {e}")
            await query.message.reply_text("❌ Произошла ошибка. Попробуйте позже.")

async def handle_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    join_request = update.chat_join_request
    user = join_request.from_user
    chat = join_request.chat
    
    try:
        # Автоматически одобряем заявку
        await join_request.approve()
        
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = (
            f"Новый участник добавлен!\n"
            f"Время: {current_time}\n"
            f"Пользователь: {user.first_name} (ID: {user.id})\n"
            f"Чат: {chat.title} (ID: {chat.id})"
        )
        logging.info(log_message)
        
    except Exception as e:
        logging.error(f"Ошибка при одобрении заявки: {e}")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = update.message.text
    user = update.message.from_user
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    request_info = (
        f"Сообщение от пользователя\n"
        f"Время: {current_time}\n"
        f"От: {user.first_name} (ID: {user.id})\n"
        f"Текст: {text}"
    )
    logging.info(request_info)

def main() -> None:
    application = Application.builder().token(TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.add_handler(ChatJoinRequestHandler(handle_join_request))
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
